﻿Module ModN0
    Public Function No(ByRef arrayMatrix As Array, ByVal intArrRows As Integer, ByVal intArrCols As Integer, ByRef douMetricVal As Double)

        Dim arrayTempMetric(intArrRows - 2) As Double
        Dim intRowCount As Integer
        Dim intColCount As Integer
        Dim intCheckVal As Integer
        Dim intAbsence As Integer
        Dim boolStart As Boolean

        boolStart = False
        intRowCount = 0
        intColCount = 0
        intAbsence = 0

        Do While intRowCount < intArrRows - 2
            intColCount = 0
            boolStart = False

            Do While intColCount < intArrCols - 2

                intCheckVal = arrayMatrix(intRowCount, (intArrCols - 2) - intColCount)

                If intCheckVal > 0 Then boolStart = True

                If boolStart = True And intCheckVal = 0 Then

                    intAbsence = arrayTempMetric(intRowCount)
                    arrayTempMetric(intRowCount) = intAbsence + 1

                End If

                intColCount = intColCount + 1
            Loop

            intRowCount = intRowCount + 1
        Loop

        intRowCount = 0
        douMetricVal = 0

        Do While intRowCount < intArrRows - 2

            intAbsence = arrayTempMetric(intRowCount)
            douMetricVal = intAbsence + douMetricVal

            intRowCount = intRowCount + 1
        Loop

        No = douMetricVal

    End Function
End Module
