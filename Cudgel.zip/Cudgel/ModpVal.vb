﻿Module ModpVal
    Public Function subpVal(ByRef arrayMatrixVals As Array, ByVal intRandomizations As Integer, ByRef douMetricVal As Double)
        Dim intCheckVal As Integer
        Dim intRowCount As Integer
        Dim intAbsence As Integer
        Dim intObsVal As Integer

        intRowCount = 1
        intAbsence = 0
        intObsVal = arrayMatrixVals(0)

        Do While intRowCount < intRandomizations + 1

            intCheckVal = arrayMatrixVals(intRowCount)
            If intCheckVal < intObsVal + 1 Then
                intAbsence = intAbsence + 1
            Else
                intAbsence = intAbsence
            End If


            intRowCount = intRowCount + 1
        Loop

        douMetricVal = intAbsence / intRandomizations

        subpVal = douMetricVal
        'MessageBox.Show(douMetricVal.ToString & " = p-value.")
    End Function
End Module
