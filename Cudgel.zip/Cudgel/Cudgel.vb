﻿Option Explicit On

Public Class Cudgel

    'Declare variables
    Dim strInputFile As String
    Dim strOutputFile As String
    Dim ofdOpenFileDialog1 As OpenFileDialog
    Dim sfdSaveFileDialog1 As SaveFileDialog
    Dim intRandomizations As Integer 'Number of Randomizations
    Dim arrayMatrix(,) As Double
    Dim intMetricNumber As Integer
    Dim intNullNumber As Integer
    Dim boolInd As Boolean
    Dim boolOut As Boolean
    Dim boolNull As Boolean
    Dim arrayDataOut(7) As Double


    Private Sub Cudgel_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Randomize()

        'Progess Bar limits
        'Try
        '    ProgressBar1.Minimum = 0
        '    ProgressBar1.Maximum = UBound(arrayMatrix)
        'Catch ex As Exception

        'End Try

    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Open File Dialog
        ofdOpenFileDialog1 = New OpenFileDialog
        'Locate input file
        With ofdOpenFileDialog1
            .AddExtension = True
            .AutoUpgradeEnabled = True
            .CheckFileExists = True
            .CheckPathExists = True
            .DefaultExt = ".xls,.txt, .xlsx"
            .Filter = "Excel files (*.xls)|*.xls|(*xlsx)|*.xlsx | Text files (*.txt)|*.txt"
            .Multiselect = False
            .ShowHelp = False
            .Title = "Select input file."
        End With
        If ofdOpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            Try
                strInputFile = ofdOpenFileDialog1.FileName
            Catch ex As Exception


            End Try
        End If

        Label9.Text = strInputFile


    End Sub


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        sfdSaveFileDialog1 = New SaveFileDialog
        ' Must have a blank Excel workbook prepared to save data into.
        With sfdSaveFileDialog1
            .AddExtension = True
            .AutoUpgradeEnabled = True
            .CheckFileExists = False
            .CreatePrompt = True
            .CheckPathExists = True
            .DefaultExt = "xls, xlsx"
            .FileName = strOutputFile
            .ShowHelp = False
            .OverwritePrompt = False
            .Title = "Select output file."
        End With

        If sfdSaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then

        End If
        Try
            strOutputFile = sfdSaveFileDialog1.FileName
        Catch ex As Exception

        End Try

        Label10.Text = strOutputFile

    End Sub
    Public Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If RadioButton1.Checked = True Then
            Batch.Show()
            Me.Hide()
        Else

            'Error handling protocols for radio buttons
            If Label9.Text = "Select input file." Then
                MessageBox.Show("Please specify an input file.")
                Exit Sub
            End If
            If Label10.Text = "Select output file." Then
                MessageBox.Show("Please specify an output file.")
                Exit Sub
            End If
            If RadioButton1.Checked = False And RadioButton2.Checked = False Then
                MessageBox.Show("Please indicate the data format.")
                Exit Sub
            End If
            If RadioButton3.Checked = False And RadioButton4.Checked = False Then
                MessageBox.Show("Please indicate whether species are in rows or columns.")
                Exit Sub
            End If
            If RadioButton5.Checked = False And RadioButton6.Checked = False Then
                MessageBox.Show("Indicate if the packed matrix should be output or not.")
                Exit Sub
            End If
            If RadioButton7.Checked = False And RadioButton8.Checked = False Then
                MessageBox.Show("Please indicate packing method.")
                Exit Sub
            End If
            If RadioButton9.Checked = False And RadioButton10.Checked = False And RadioButton11.Checked = False And RadioButton12.Checked = False And RadioButton13.Checked = False And RadioButton14.Checked = False And RadioButton15.Checked = False And RadioButton16.Checked = False And RadioButton17.Checked = False And RadioButton18.Checked = False And RadioButton19.Checked = False Then
                MessageBox.Show("Please select a metric.")
                Exit Sub
            End If
            If RadioButton20.Checked = False And RadioButton21.Checked = False And RadioButton22.Checked = False And RadioButton23.Checked = False And RadioButton24.Checked = False And RadioButton25.Checked = False And RadioButton26.Checked = False And RadioButton27.Checked = False And RadioButton28.Checked = False Then
                MessageBox.Show("Please select a null model.")
                Exit Sub
            End If

            ''Error handling protocol for number of randomizations
            'If intRandomizations < 100 Then
            '    MessageBox.Show("Please enter a numerical value between 100 and 10,000.")
            '    Exit Sub
            'End If
            'If intRandomizations > 10000 Then
            '    MessageBox.Show("Please enter a numerical value between 100 and 10,000.")
            '    Exit Sub
            'End If


            'Assign Randomizations Text Box value to variable
            Try
                intRandomizations = TextBox1.Text
            Catch ex As InvalidCastException

            End Try


            'Loading data into array
            Try

                'Make independant variable button boolean
                If RadioButton8.Checked = True Then
                    boolInd = True
                Else
                    boolInd = False
                End If

                'Make matrix output radio button boolean
                If RadioButton5.Checked = True Then
                    boolOut = True
                Else
                    boolOut = False
                End If

                'Put metric selection into a variable.
                If RadioButton9.Checked = True Then intMetricNumber = 1

                If RadioButton10.Checked = True Then intMetricNumber = 2

                If RadioButton11.Checked = True Then intMetricNumber = 3

                If RadioButton12.Checked = True Then intMetricNumber = 4

                If RadioButton13.Checked = True Then intMetricNumber = 5

                If RadioButton14.Checked = True Then intMetricNumber = 6

                If RadioButton15.Checked = True Then intMetricNumber = 7

                If RadioButton16.Checked = True Then intMetricNumber = 8

                If RadioButton17.Checked = True Then intMetricNumber = 9

                If RadioButton18.Checked = True Then intMetricNumber = 10

                If RadioButton19.Checked = True Then intMetricNumber = 11



                'Put null model selection into a variable.

                If RadioButton20.Checked = True Then intNullNumber = 1


                If RadioButton21.Checked = True Then intNullNumber = 2

                If RadioButton22.Checked = True Then intNullNumber = 3

                If RadioButton23.Checked = True Then intNullNumber = 4

                If RadioButton24.Checked = True Then intNullNumber = 5

                If RadioButton25.Checked = True Then intNullNumber = 6

                If RadioButton26.Checked = True Then intNullNumber = 7

                If RadioButton27.Checked = True Then intNullNumber = 8

                If RadioButton28.Checked = True Then intNullNumber = 9


                Call subloopInput(strInputFile, boolInd, boolOut, strOutputFile, boolNull, intNullNumber, intMetricNumber, intRandomizations, arrayDataOut)

            Catch ex As Exception

            End Try
        End If

        If RadioButton2.Checked = True Then
            MessageBox.Show("Run complete.")
        End If

    End Sub


    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        ' Exits program
        Application.Exit()


    End Sub

    Private Sub Button4_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        'Exits Program
        Application.Exit()

    End Sub


End Class
