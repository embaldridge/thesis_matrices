﻿Module ModloopSummarize
    Public Function MatrixSummarize(ByRef arrayMatrix As Array, ByRef boolInd As Boolean, ByVal intArrRows As Integer, ByVal intArrCols As Integer, ByVal intRandomCounter As Integer)

        Dim intCountRows As Integer
        Dim intCountCols As Integer

        'Copy independant variable and species richness to blank row and column
        If intRandomCounter = 0 And boolInd = True Then
            'MessageBox.Show(" Matrix summarize.")
            Dim intRowCopy As Double
            Dim intColCopy As Double

            intCountRows = 0
            intCountCols = 0
            'Copy independant variable row to blank row
            Do While intCountCols < intArrCols - 1

                intRowCopy = arrayMatrix(0, intCountCols)

                arrayMatrix(intArrRows - 1, intCountCols) = intRowCopy

                intCountCols = intCountCols + 1

            Loop


            'Copy independant variable column to blank column

            intCountCols = 0
            intCountRows = 0

            Do While intCountRows < intArrRows - 1

                intColCopy = arrayMatrix(intCountRows, 0)

                arrayMatrix(intCountRows, intArrCols - 1) = intColCopy

                intCountRows = intCountRows + 1
            Loop



        Else
            'MessageBox.Show("Null summarize")

            Dim intRowSum As Integer
            Dim intColSum As Integer

            intCountCols = 1
            intCountRows = 1

            'Sum rows
            Do While intCountRows < intArrRows - 1
                intCountCols = 1
                intRowSum = 0

                Do While intCountCols < intArrCols - 1

                    intRowSum = arrayMatrix(intCountRows, intCountCols) + arrayMatrix(intCountRows, intArrCols - 1)

                    arrayMatrix(intCountRows, intArrCols - 1) = intRowSum

                    intCountCols = intCountCols + 1
                Loop

                intCountRows = intCountRows + 1

            Loop

            'Sum columns
            intCountCols = 1
            Do While intCountCols < intArrCols - 1
                intCountRows = 1
                intColSum = 0

                Do While intCountRows < intArrRows - 1

                    intColSum = arrayMatrix(intCountRows, intCountCols) + arrayMatrix(intArrRows - 1, intCountCols)

                    arrayMatrix(intArrRows - 1, intCountCols) = intColSum

                    intCountRows = intCountRows + 1
                Loop

                intCountCols = intCountCols + 1

            Loop

        End If

        MatrixSummarize = arrayMatrix

    End Function

End Module
