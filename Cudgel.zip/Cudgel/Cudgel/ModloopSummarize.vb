﻿Module ModloopSummarize
    Public Sub MatrixSummarize(ByRef arrayMatrix As Array, ByVal intArrRows As Integer, ByVal intArrCols As Integer, ByRef boolInd As Boolean, ByRef boolOut As Boolean, ByVal strOutputFile As String, ByRef arraySpecies As Array, ByRef arraySites As Array, ByRef boolNull As Boolean, ByVal intMetricNumber As Integer, ByVal intSpeciesRows As Integer, ByVal intSitesCols As Integer, ByVal intRandomizations As Integer, ByVal intRandomCounter As Integer)

        Dim intCountRows As Integer
        Dim intCountCols As Integer

        'Copy independant variable and species richness to blank row and column
        If boolInd = True Then
            'MessageBox.Show(" Matrix summarize.")
            Dim intRowCopy As Integer
            Dim intColCopy As Integer

            intCountRows = 0
            intCountCols = 0
            'Copy independant variable row to blank row
            Do While intCountCols < intArrCols - 1

                intRowCopy = arrayMatrix(0, intCountCols)

                arrayMatrix(intArrRows - 1, intCountCols) = intRowCopy

                intCountCols = intCountCols + 1

            Loop


            'Copy independant variable column to blank column

            intCountCols = 0
            intCountRows = 0

            Do While intCountRows < intArrRows - 1

                intColCopy = arrayMatrix(intCountRows, 0)

                arrayMatrix(intCountRows, intArrCols - 1) = intColCopy

                intCountRows = intCountRows + 1
            Loop



        Else
            'MessageBox.Show("Null summarize")

            Dim intRowSum As Integer
            Dim intColSum As Integer

            intCountCols = 1
            intCountRows = 1

            'Sum rows
            Do While intCountRows < intArrRows - 1
                intCountCols = 1
                intRowSum = 0

                Do While intCountCols < intArrCols - 1

                    intRowSum = arrayMatrix(intCountRows, intCountCols) + arrayMatrix(intCountRows, intArrCols - 1)

                    arrayMatrix(intCountRows, intArrCols - 1) = intRowSum

                    intCountCols = intCountCols + 1
                Loop

                intCountRows = intCountRows + 1

            Loop

            'Sum columns
            intCountCols = 1
            Do While intCountCols < intArrCols - 1
                intCountRows = 1
                intColSum = 0

                Do While intCountRows < intArrRows - 1

                    intColSum = arrayMatrix(intCountRows, intCountCols) + arrayMatrix(intArrRows - 1, intCountCols)

                    arrayMatrix(intArrRows - 1, intCountCols) = intColSum

                    intCountRows = intCountRows + 1
                Loop

                intCountCols = intCountCols + 1

            Loop

        End If


        'Call PackMatrix
        PackMatrix(arrayMatrix, arraySpecies, arraySites, intArrRows, intArrCols, strOutputFile, boolOut, boolNull, intMetricNumber, intSpeciesRows, intSitesCols, intRandomizations, intRandomCounter)

    End Sub

End Module
