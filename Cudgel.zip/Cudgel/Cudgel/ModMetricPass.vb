﻿Module ModMetricPass

    Public Sub MetricPass(ByRef arrayMatrixPacked As Array, ByVal intArrRows As Integer, ByVal intArrCols As Integer, ByVal intMetricNumber As Integer, ByRef boolNull As Boolean, ByVal strOutputFile As String, ByVal intRandomCounter As Integer, ByVal intRandomizations As Integer)
        'MessageBox.Show("Metric Pass")

        If intMetricNumber = 1 Then No(arrayMatrixPacked, intArrRows, intArrCols, boolNull, strOutputFile, intRandomCounter, intRandomizations) Else 
        If intMetricNumber = 2 Then N1(arrayMatrixPacked, intArrRows, intArrCols, boolNull, strOutputFile, intRandomCounter, intRandomizations) Else 
        If intMetricNumber = 3 Then Ua(arrayMatrixPacked, intArrRows, intArrCols, boolNull, strOutputFile, intRandomCounter, intRandomizations) Else 
        If intMetricNumber = 4 Then Up(arrayMatrixPacked, intArrRows, intArrCols, boolNull, strOutputFile, intRandomCounter, intRandomizations) Else 
        If intMetricNumber = 5 Then Ut(arrayMatrixPacked, intArrRows, intArrCols, boolNull, strOutputFile, intRandomCounter, intRandomizations) Else 
        If intMetricNumber = 6 Then Nc(arrayMatrixPacked, intArrRows, intArrCols, boolNull, strOutputFile, intRandomCounter, intRandomizations) Else 
        If intMetricNumber = 7 Then D(arrayMatrixPacked, intArrRows, intArrCols, boolNull, strOutputFile, intRandomCounter, intRandomizations) Else 
        If intMetricNumber = 8 Then BR(arrayMatrixPacked, intArrRows, intArrCols, boolNull, strOutputFile, intRandomCounter, intRandomizations) Else 
        If intMetricNumber = 9 Then T(arrayMatrixPacked, intArrRows, intArrCols, boolNull, strOutputFile, intRandomCounter, intRandomizations) Else 
        If intMetricNumber = 10 Then HH(arrayMatrixPacked, intArrRows, intArrCols, boolNull, strOutputFile, intRandomCounter, intRandomizations) Else 
        If intMetricNumber = 11 Then NODF(arrayMatrixPacked, intArrRows, intArrCols, boolNull, strOutputFile, intRandomCounter, intRandomizations) Else 

    End Sub

End Module
