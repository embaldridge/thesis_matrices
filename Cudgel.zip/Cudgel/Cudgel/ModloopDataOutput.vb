﻿Module ModloopDataOutput
    Public Sub DataOutput(ByRef boolNull As Boolean, ByVal deciMetricVal As Decimal, ByVal strOutputFile As String, ByRef intRandomCounter As Integer, ByVal intRandomizations As Integer)


        'Dim xlsObject3 As Microsoft.Office.Interop.Excel.Application
        'xlsObject3 = New Microsoft.Office.Interop.Excel.Application

        'Dim wbkOutputFile As Microsoft.Office.Interop.Excel.Workbook
        'Dim wksOutputSheet As Microsoft.Office.Interop.Excel.Worksheet

        ''Open blank output file- Must create blank workbook before running analysis.
        'xlsObject3.Application.Workbooks.Open(strOutputFile)
        'wbkOutputFile = GetObject(strOutputFile)
        'wksOutputSheet = wbkOutputFile.Worksheets(1) 'data is sent to the first worksheet.

        'Dim rCell3 As Microsoft.Office.Interop.Excel.Range

        'If boolNull = True Then

        '    rCell3 = wksOutputSheet.Cells(intRandomCounter + 4, 1)
        '    rCell3.Value = deciMetricVal

        'Else

        '    MessageBox.Show("This is the observed value.")
        '    rCell3 = wksOutputSheet.Cells(1)
        '    rCell3.Value = "Observed value"
        '    rCell3 = wksOutputSheet.Cells(2, 1)
        '    rCell3.Value = deciMetricVal
        '    rCell3 = wksOutputSheet.Cells(4, 1)
        '    rCell3.Value = "Expected values"

        'End If

        ''Save output file
        'wbkOutputFile.Save()

        ''Cleanup and close Excel application
        'wbkOutputFile.Close()
        'xlsObject3.Application.Quit()

        If intRandomCounter = intRandomizations Then

            MessageBox.Show("The run is complete.")

        End If

    End Sub

End Module
