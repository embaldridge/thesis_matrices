﻿Module ModloopInput



    Sub subloopInput(ByVal strInputFile As String, ByVal strOutputFile As String, ByRef boolOut As Boolean, ByRef boolInd As Boolean, ByRef boolNull As Boolean, ByVal intMetricNumber As Integer, ByVal intNullNumber As Integer, ByRef intRandomizations As Integer, ByVal intRandomCounter As Integer)
        'Set up invisible Excel to handle input data
        Dim xlsObject1 As Microsoft.Office.Interop.Excel.Application
        xlsObject1 = New Microsoft.Office.Interop.Excel.Application

        Dim wbkInputFile As Microsoft.Office.Interop.Excel.Workbook
        Dim wksInputSheet As Microsoft.Office.Interop.Excel.Worksheet

        'Open input file
        xlsObject1.Application.Workbooks.Open(strInputFile)
        wbkInputFile = GetObject(strInputFile)
        wksInputSheet = wbkInputFile.Worksheets(1) 'Data must be in the first worksheet

        'Get input data file parameters
        Dim intDataRows As Integer
        Dim intDataCols As Integer

        Dim rRows As Microsoft.Office.Interop.Excel.Range
        Dim rCols As Microsoft.Office.Interop.Excel.Range

        rRows = wksInputSheet.Range("A:A")
        rCols = wksInputSheet.Range("1:1")

        intDataRows = xlsObject1.WorksheetFunction.CountA(rRows)
        intDataCols = xlsObject1.WorksheetFunction.CountA(rCols)

        'Set up data array
        Dim intArrRows As Integer
        Dim intArrCols As Integer
        Dim intSpeciesRows As Integer
        Dim intSitesCols As Integer

        'intArrRows = intDataRows - 1
        intArrRows = intDataRows
        intSpeciesRows = intDataRows
        intSitesCols = intDataRows

        'intArrCols = intDataCols - 1
        intArrCols = intDataCols

        'Setup data array

        Dim arrayMatrix(intArrRows, intArrCols) As Double 'Declare matrix data as arrayMatrix

        Dim arraySpecies(intSpeciesRows) As String

        Dim arraySites(intSitesCols) As String


        'Load data array
        Dim rCell As Microsoft.Office.Interop.Excel.Range

        Dim intRowLoop As Integer
        Dim intColLoop As Integer

        Dim intXlsRowPos As Integer
        Dim intXlsColPos As Integer


        'Load species name array

        intRowLoop = 0
        intColLoop = 0

        Do While intRowLoop < intDataRows

            rCell = wksInputSheet.Cells(intRowLoop + 1, 1)

            arraySpecies(intRowLoop) = rCell.Value

            intRowLoop = intRowLoop + 1

        Loop
        'MessageBox.Show("Species loaded.")


        'Load sites array
        intRowLoop = 0
        intColLoop = 0

        Do While intRowLoop < intDataCols

            rCell = wksInputSheet.Cells(intRowLoop + 1)

            arraySites(intRowLoop) = rCell.Value

            intRowLoop = intRowLoop + 1

        Loop
        'MessageBox.Show("Sites loaded.")


        'Load array matrix
        intRowLoop = 0
        intColLoop = 0

        Do While intRowLoop < intDataRows
            intColLoop = 0
            intXlsRowPos = intRowLoop + 2

            Do While intColLoop < intDataCols
                intXlsColPos = intColLoop + 2

                rCell = wksInputSheet.Cells(intXlsRowPos, intXlsColPos)

                arrayMatrix(intRowLoop, intColLoop) = rCell.Value

                intColLoop = intColLoop + 1

            Loop

            intRowLoop = intRowLoop + 1

        Loop

        'Cleanup and close Excel application
        wbkInputFile.Close()
        xlsObject1.Application.Quit()

        MessageBox.Show("Data loaded.") ''''

        NullPass(arrayMatrix, intArrRows, intArrCols, False, False, strOutputFile, True, intNullNumber, intMetricNumber, arraySpecies, arraySites, intSpeciesRows, intSitesCols, intRandomizations, intRandomCounter)

        'MatrixSummarize(arrayMatrix, intArrRows, intArrCols, boolInd, boolOut, strOutputFile, arraySpecies, arraySites, boolNull, intMetricNumber, intSpeciesRows, intSitesCols, intRandomizations, intRandomCounter)

       
    End Sub



End Module
