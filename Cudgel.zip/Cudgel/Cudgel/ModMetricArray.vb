﻿Module ModMetricArray

    Sub MetricArray(ByRef arrayMetricVals As Array, ByVal intRandomCounter As Integer, ByVal intRandomizations As Integer, ByVal douMetricVal As Double, ByVal strOutputFile As String)

        arrayMetricVals(intRandomCounter) = douMetricVal

        If intRandomCounter = intRandomizations Then

            DataOutput(strOutputFile, intRandomizations, arrayMetricVals)

        End If

    End Sub

End Module
