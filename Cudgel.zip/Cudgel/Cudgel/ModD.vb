﻿Module ModD
    Public Sub D(ByRef arrayMatrixPacked As Array, ByVal intArrRows As Integer, ByVal intArrCols As Integer, ByRef boolNull As Boolean, ByVal strOutputFile As String, ByVal intRandomCounter As Integer, ByVal intRandomizations As Integer)
        Dim intMetricVal As Integer


        Call DataOutput(boolNull, intMetricVal, strOutputFile, intRandomCounter, intRandomizations)
    End Sub
End Module
