﻿Module ModUa
    Public Sub Ua(ByRef arrayMatrixPacked As Array, ByVal intArrRows As Integer, ByVal intArrCols As Integer, ByRef boolNull As Boolean, ByVal strOutputFile As String, ByVal intRandomCounter As Integer, ByVal intRandomizations As Integer)
        Dim deciMetricVal As Integer

        Call DataOutput(boolNull, deciMetricVal, strOutputFile, intRandomCounter, intRandomizations)
    End Sub
End Module
