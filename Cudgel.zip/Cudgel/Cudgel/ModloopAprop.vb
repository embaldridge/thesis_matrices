﻿Module ModloopAprop
    Public Sub Aprop(ByRef arrayMatrix As Array, ByRef intArrRows As Integer, ByRef intArrCols As Integer, ByRef boolInd As Boolean, ByRef boolOut As Boolean, ByVal strOutputFile As String, ByRef boolNull As Boolean, ByVal intNullNumber As Integer, ByVal intMetricNumber As Integer, ByRef arraySpecies As Array, ByRef arraySites As Array, ByVal intSpeciesRows As Integer, ByVal intSitesCols As Integer, ByVal intRandomizations As Integer, ByRef intRandomCounter As Integer)

        Do While intRandomCounter < intRandomizations

            'Randomize matrix

            Call MatrixSummarize(arrayMatrix, intArrRows, intArrCols, False, False, strOutputFile, arraySpecies, arraySites, True, intMetricNumber, intSpeciesRows, intSitesCols, intRandomizations, intRandomCounter)

            intRandomCounter = intRandomCounter + 1

        Loop
    End Sub
End Module
