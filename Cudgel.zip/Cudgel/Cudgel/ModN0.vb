﻿Module ModN0
    Public Sub No(ByRef arrayMatrixPacked As Array, ByVal intArrRows As Integer, ByVal intArrCols As Integer, ByRef boolNull As Boolean, ByVal strOutputFile As String, ByVal intRandomCounter As Integer, ByVal intRandomizations As Integer)

        'MessageBox.Show("This is subroutine No.")
        Dim deciMetricVal As Decimal

        deciMetricVal = 7.998

        Call DataOutput(boolNull, deciMetricVal, strOutputFile, intRandomCounter, intRandomizations)
    End Sub
End Module
