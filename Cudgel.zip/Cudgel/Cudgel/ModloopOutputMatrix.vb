﻿Module ModloopOutputMatrix

    Public Sub OutputMatrix(ByRef arrayMatrixPacked As Array, ByRef arraySpeciesKey As Array, ByRef arraySitesKey As Array, ByVal intArrRows As Integer, ByVal intArrCols As Integer, ByVal strOutputFile As String)

        Dim xlsObject2 As Microsoft.Office.Interop.Excel.Application
        xlsObject2 = New Microsoft.Office.Interop.Excel.Application

        Dim wbkOutputFile As Microsoft.Office.Interop.Excel.Workbook
        Dim wksOutputSheet As Microsoft.Office.Interop.Excel.Worksheet

        'Open blank output file- Must create blank workbook before running analysis.
        xlsObject2.Application.Workbooks.Open(strOutputFile)
        wbkOutputFile = GetObject(strOutputFile)
        wksOutputSheet = wbkOutputFile.Worksheets(2) 'matrix is sent to the second worksheet.

        Dim intRowCounter As Integer
        intRowCounter = 0

        Dim intColCounter As Integer
        intColCounter = 0


        Dim rCell2 As Microsoft.Office.Interop.Excel.Range


        'Load species data
        intRowCounter = 0
        intColCounter = 0

        Do While intRowCounter < intArrRows

            rCell2 = wksOutputSheet.Cells(intRowCounter + 1, 1)
            rCell2.Value = arraySpeciesKey(intRowCounter)

            intRowCounter = intRowCounter + 1

        Loop

        'Load sites data
        intRowCounter = 0
        intColCounter = 0

        Do While intColCounter < intArrCols

            rCell2 = wksOutputSheet.Cells(1, intColCounter + 1)
            rCell2.Value = arraySitesKey(intColCounter)

            intColCounter = intColCounter + 1

        Loop

        'Load matrix data 
        intRowCounter = 0
        intColCounter = 0

        Do While intRowCounter < intArrRows
            intColCounter = 0

            Do While intColCounter < intArrCols

                rCell2 = wksOutputSheet.Cells(intRowCounter + 2, intColCounter + 2) 'Must have +1 to make the array line up with the range.  +2 shifts it over 1.

                rCell2.Value = arrayMatrixPacked(intRowCounter, intColCounter)

                intColCounter = intColCounter + 1

            Loop

            intRowCounter = intRowCounter + 1

        Loop

        'Save output file
        wbkOutputFile.Save()

        'Clean up and close invisible Excel
        wbkOutputFile.Close()
        xlsObject2.Application.Quit()

        MessageBox.Show("The matrix has been output.") ''''

    End Sub
End Module
