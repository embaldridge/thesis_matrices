﻿Module ModloopExcel

    Sub subloopExcel(ByVal strInputFile As String, ByVal strOutputFile As String, ByRef RadioButton5 As Object)
        'Set up invisible Excel to handle input data
        Dim xlsObject1 As Microsoft.Office.Interop.Excel.Application
        xlsObject1 = New Microsoft.Office.Interop.Excel.Application

        Dim wbkInputFile As Microsoft.Office.Interop.Excel.Workbook
        Dim wksInputSheet As Microsoft.Office.Interop.Excel.Worksheet

        'Open input file
        xlsObject1.Application.Workbooks.Open(strInputFile)
        wbkInputFile = GetObject(strInputFile)
        wksInputSheet = wbkInputFile.Worksheets(1) 'Data must be in the first worksheet

        'Get input data file parameters
        Dim intDataRows As Integer
        Dim intDataCols As Integer

        Dim rRows As Microsoft.Office.Interop.Excel.Range
        Dim rCols As Microsoft.Office.Interop.Excel.Range

        rRows = wksInputSheet.Range("A:A")
        rCols = wksInputSheet.Range("1:1")

        intDataRows = xlsObject1.WorksheetFunction.CountA(rRows)
        intDataCols = xlsObject1.WorksheetFunction.CountA(rCols)

        'Set up data array
        Dim intArrRows As Integer
        Dim intArrCols As Integer


        'intArrRows = intRows - 1
        intArrRows = intDataRows

        'intArrRows = intRows - 1
        intArrCols = intDataCols

        'Setup data array
        Dim arrayMatrix(intArrRows, intArrCols) As Double 'Declare matrix data as arrayMatrix

        Dim arraySpecies(intArrRows) As String

        Dim arraySites(intArrCols) As String

        'Load data array
        Dim rCell As Microsoft.Office.Interop.Excel.Range

        Dim intRowLoop As Integer
        Dim intColLoop As Integer

        intRowLoop = 0
        intColLoop = 0

        Dim intXlsRowPos As Integer
        Dim intXlsColPos As Integer


        'Load species name array
        intRowLoop = 0
        intColLoop = 0

        Do While intRowLoop < intDataRows

            rCell = wksInputSheet.Cells(intRowLoop + 1, 1)
            arraySpecies(intRowLoop) = rCell.Value
            intRowLoop = intRowLoop + 1

        Loop
        'MessageBox.Show("Species loaded.")


        'Load sites array
        intRowLoop = 0
        intColLoop = 0

        Do While intRowLoop < intDataCols

            rCell = wksInputSheet.Cells(intRowLoop + 1)
            arraySites(intRowLoop) = rCell.Value
            intRowLoop = intRowLoop + 1

        Loop
        'MessageBox.Show("Sites loaded.")


        'Load array matrix
        intRowLoop = 0
        intColLoop = 0

        Do While intRowLoop < intDataRows
            intColLoop = 0
            intXlsRowPos = intRowLoop + 2

            Do While intColLoop < intDataCols
                intXlsColPos = intColLoop + 2

                rCell = wksInputSheet.Cells(intXlsRowPos, intXlsColPos)

                arrayMatrix(intRowLoop, intColLoop) = rCell.Value

                intColLoop = intColLoop + 1

            Loop

            intRowLoop = intRowLoop + 1

        Loop

        'Cleanup and close Excel application
        wbkInputFile.Close()
        xlsObject1.Application.Quit()

        MessageBox.Show("Data loaded.") ''''

        'Call PackMatrix
        PackMatrix(arrayMatrix, arraySpecies, arraySites, intArrRows, intArrCols, strOutputFile, RadioButton5)


    End Sub

    Public Sub PackMatrix(ByRef arrayMatrix As Array, ByRef arraySpecies As Array, ByRef arraySites As Array, ByVal intArrRows As Integer, ByVal intArrCols As Integer, ByVal strOutputFile As String, ByRef RadioButton5 As Object)

        'Sort the matrix array.


        'Call OutputMatrix
        If RadioButton5.Checked = True Then
            OutputMatrix(arrayMatrix, arraySpecies, arraySites, intArrRows, intArrCols, strOutputFile)
        End If

    End Sub

    Public Sub OutputMatrix(ByRef arrayMatrix As Array, ByRef arraySpecies As Array, ByRef arraySites As Array, ByVal intArrRows As Integer, ByVal intArrCols As Integer, ByVal strOutputFile As String)

        Dim xlsObject2 As Microsoft.Office.Interop.Excel.Application
        xlsObject2 = New Microsoft.Office.Interop.Excel.Application

        Dim wbkOutputFile As Microsoft.Office.Interop.Excel.Workbook
        Dim wksOutputSheet As Microsoft.Office.Interop.Excel.Worksheet

        'Open blank output file- Must create blank workbook before running analysis.
        xlsObject2.Application.Workbooks.Open(strOutputFile)
        wbkOutputFile = GetObject(strOutputFile)
        wksOutputSheet = wbkOutputFile.Worksheets(2) 'matrix is sent to the second worksheet.

        Dim intRowCounter As Integer
        intRowCounter = 0

        Dim intColCounter As Integer
        intColCounter = 0


        Dim rCell2 As Microsoft.Office.Interop.Excel.Range


        'Load species data
        intRowCounter = 0
        intColCounter = 0

        Do While intRowCounter < intArrRows

            rCell2 = wksOutputSheet.Cells(intRowCounter + 1, 1)
            rCell2.Value = arraySpecies(intRowCounter)
            intRowCounter = intRowCounter + 1

        Loop
        'MessageBox.Show("Species names have been output.")



        'Load sites data
        intRowCounter = 0
        intColCounter = 0

        Do While intColCounter < intArrCols

            rCell2 = wksOutputSheet.Cells(1, intColCounter + 1)
            rCell2.Value = arraySites(intColCounter)
            intColCounter = intColCounter + 1

        Loop
        'MessageBox.Show("Site names have been output.")



        'Load matrix data 
        intRowCounter = 0
        intColCounter = 0

        Do While intRowCounter < intArrRows
            intColCounter = 0

            Do While intColCounter < intArrCols

                rCell2 = wksOutputSheet.Cells(intRowCounter + 2, intColCounter + 2) 'Must have +1 to make the array line up with the range.  +2 shifts it over 1.

                rCell2.Value = arrayMatrix(intRowCounter, intColCounter)

                intColCounter = intColCounter + 1

            Loop

            intRowCounter = intRowCounter + 1

        Loop

        'Save output file
        wbkOutputFile.Save()

        'Clean up and close invisible Excel
        wbkOutputFile.Close()
        xlsObject2.Application.Quit()

        MessageBox.Show("Data has been output.") ''''

    End Sub

End Module
