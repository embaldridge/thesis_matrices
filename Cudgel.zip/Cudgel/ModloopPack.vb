﻿Module ModloopPack
    Public Function PackMatrix(ByRef arrayMatrix As Array, ByRef arraySpecies As Array, ByRef arraySites As Array, ByVal intArrRows As Integer, ByVal intArrCols As Integer, ByVal intSpeciesRows As Integer, ByVal intSitesCols As Integer)

        'Declare new variables
        Dim arraySpeciesKey(intSpeciesRows) As String
        Dim arraySitesKey(intSitesCols) As String
        Dim arrayRowKey(intArrRows - 2, 1) As Double
        Dim arrayTempRows(intArrRows - 2, intArrCols) As Double
        Dim arrayTempMatrix(intArrRows, intArrCols) As Double
        Dim arrayColKey(1, intArrCols - 2) As Double
        Dim arrayTempCols(intArrRows, intArrCols - 2) As Double
        Dim intRowCount As Integer
        Dim intColCount As Integer
        Dim intCellCopy As Double
        Dim strKeyValue As String
        Dim intCompare1 As Double
        Dim intCompare2 As Double
        Dim intSwitch1 As Double
        Dim intSwitch2 As Double
        Dim intPosRef As Integer
        Dim intPosCount As Integer


        ' ' ' Sorting array rows ' ' '
        ''Fill row key array '' 
        'Fill row key with sorting values
        intRowCount = 0
        intColCount = 0
        Do While intRowCount < intArrRows - 2

            intCellCopy = arrayMatrix(intRowCount + 1, intArrCols - 1)
            arrayRowKey(intRowCount, 0) = intCellCopy

            intRowCount = intRowCount + 1

        Loop

        'Fill row key with sorting position values
        intRowCount = 0
        intColCount = 0
        intPosCount = 0

        Do While intRowCount < intArrRows - 2

            intCellCopy = intPosCount
            arrayRowKey(intRowCount, 1) = intCellCopy + 1

            intPosCount = intPosCount + 1
            intRowCount = intRowCount + 1

        Loop

        ''Sort row key values
        'Switch values
        intRowCount = 0
        intColCount = 0
        intPosCount = 0

        Do While intPosCount < intArrRows - 2
            intColCount = 0

            Do While intColCount < intArrRows - 2
                intRowCount = 0

                Do While intRowCount < intArrRows - 2

                    intCompare1 = arrayRowKey(intColCount, 0)
                    intCompare2 = arrayRowKey(intRowCount, 0)
                    intSwitch1 = arrayRowKey(intColCount, 1)
                    intSwitch2 = arrayRowKey(intRowCount, 1)

                    If intCompare1 < intCompare2 And intSwitch1 < intSwitch2 Then

                        arrayRowKey(intColCount, 1) = intSwitch2
                        arrayRowKey(intRowCount, 1) = intSwitch1

                    Else

                        arrayRowKey(intColCount, 1) = intSwitch1
                        arrayRowKey(intRowCount, 1) = intSwitch2

                    End If

                    intRowCount = intRowCount + 1

                Loop

                intColCount = intColCount + 1
            Loop

            intPosCount = intPosCount + 1
        Loop
        ''Fill temporary row array
        'Get row value from row key and use to sort original matrix into temporary row array
        intRowCount = 0
        intColCount = 0

        Do While intRowCount < intArrRows - 2
            intColCount = 0
            intPosCount = arrayRowKey(intRowCount, 1)
            intPosRef = intPosCount - 1

            Do While intColCount < intArrCols

                intCellCopy = arrayMatrix(intRowCount + 1, intColCount)
                arrayTempRows(intPosRef, intColCount) = intCellCopy

                intColCount = intColCount + 1
            Loop


            intRowCount = intRowCount + 1

        Loop


        '' Fill species key array
        ' Fill key array with first two labels
        strKeyValue = arraySpecies(0)
        arraySpeciesKey(0) = strKeyValue
        strKeyValue = arraySpecies(1)
        arraySpeciesKey(1) = strKeyValue

        ' Fill key array with sorted labels
        intRowCount = 0
        intColCount = 0

        Do While intRowCount < intArrRows - 2

            intPosCount = arrayRowKey(intRowCount, 1)
            intPosRef = intPosCount + 1

            strKeyValue = arraySpecies(intRowCount + 2)
            arraySpeciesKey(intPosRef) = strKeyValue

            intRowCount = intRowCount + 1
        Loop


        ' ' ' Fill temporary matrix ' ' '
        '' Fill intial row of the temporary matrix
        ' Fill row zero with data from matrix array
        intRowCount = 0
        intColCount = 0
        Do While intColCount < intArrCols

            intCellCopy = arrayMatrix(intRowCount, intColCount)
            arrayTempMatrix(intRowCount, intColCount) = intCellCopy

            intColCount = intColCount + 1
        Loop

        '' Move sorted row data
        ' Fill temporary matrix with temporary row array
        intRowCount = 0
        intColCount = 0
        Do While intRowCount < intArrRows - 2
            intColCount = 0
            Do While intColCount < intArrCols

                intCellCopy = arrayTempRows(intRowCount, intColCount)
                arrayTempMatrix(intRowCount + 1, intColCount) = intCellCopy

                intColCount = intColCount + 1
            Loop

            intRowCount = intRowCount + 1
        Loop

        ''Fill final row of the temporary array
        'Fill final temporary array row with matrix array data
        intRowCount = 0
        intColCount = 0
        Do While intColCount < intArrCols

            intCellCopy = arrayMatrix(intArrRows - 1, intColCount)
            arrayTempMatrix(intArrRows - 1, intColCount) = intCellCopy

            intColCount = intColCount + 1
        Loop

        ' ' ' Sorting array columns ' ' '
        '' Fill column key array
        'Fill column key array with values from temporary matrix
        intRowCount = 0
        intColCount = 0
        Do While intColCount < intArrCols - 2

            intCellCopy = arrayMatrix(intArrRows - 1, intColCount + 1)
            arrayColKey(0, intColCount) = intCellCopy

            intColCount = intColCount + 1
        Loop

        'Fill column key array with sorting position values
        intRowCount = 0
        intColCount = 0
        intPosCount = 0
        Do While intColCount < intArrCols - 2

            intCellCopy = intPosCount
            arrayColKey(1, intColCount) = intCellCopy + 1

            intPosCount = intPosCount + 1
            intColCount = intColCount + 1

        Loop

        ''Sort column key values
        'Switch values
        intRowCount = 0
        intColCount = 0
        intPosCount = 0

        Do While intPosCount < intArrCols - 2
            intRowCount = 0

            Do While intRowCount < intArrCols - 2
                intColCount = 0

                Do While intColCount < intArrCols - 2

                    intCompare1 = arrayColKey(0, intRowCount)
                    intCompare2 = arrayColKey(0, intColCount)
                    intSwitch1 = arrayColKey(1, intRowCount)
                    intSwitch2 = arrayColKey(1, intColCount)

                    If intCompare1 < intCompare2 And intSwitch1 < intSwitch2 Then

                        arrayColKey(1, intRowCount) = intSwitch2
                        arrayColKey(1, intColCount) = intSwitch1

                    Else

                        arrayColKey(1, intRowCount) = intSwitch1
                        arrayColKey(1, intColCount) = intSwitch2

                    End If

                    intColCount = intColCount + 1

                Loop

                intRowCount = intRowCount + 1
            Loop

            intPosCount = intPosCount + 1
        Loop

        ''Fill temporary column array
        'Get column value from column key and use to sort temporary row packed matrix into temporary column array
        intRowCount = 0
        intColCount = 0

        Do While intColCount < intArrCols - 2
            intRowCount = 0
            intPosCount = arrayColKey(1, intColCount)
            intPosRef = intPosCount - 1

            Do While intRowCount < intArrRows

                intCellCopy = arrayTempMatrix(intRowCount, intColCount + 1)
                arrayTempCols(intRowCount, intPosRef) = intCellCopy

                intRowCount = intRowCount + 1
            Loop

            intColCount = intColCount + 1
        Loop

        '' Fill sites key array
        ' Fill key array with first two labels
        strKeyValue = arraySites(0)
        arraySitesKey(0) = strKeyValue
        strKeyValue = arraySites(1)
        arraySitesKey(1) = strKeyValue

        ' Fill key array with sorted labels
        intRowCount = 0
        intColCount = 0

        Do While intColCount < intArrCols - 2

            intPosCount = arrayColKey(1, intColCount)
            intPosRef = intPosCount + 1

            strKeyValue = arraySites(intColCount + 2)
            arraySitesKey(intPosRef) = strKeyValue

            intPosCount = intPosCount + 1
            intColCount = intColCount + 1
        Loop

        ' ' ' Fill final packed matrix ' ' '
        '' Fill intial column of the packed matrix
        ' Fill column zero with data from matrix array
        intRowCount = 0
        intColCount = 0
        Do While intRowCount < intArrRows

            intCellCopy = arrayTempMatrix(intRowCount, intColCount)
            arrayMatrix(intRowCount, intColCount) = intCellCopy

            intRowCount = intRowCount + 1
        Loop

        '' Move sorted column data
        ' Fill temporary matrix with temporary column array
        intRowCount = 0
        intColCount = 0
        Do While intColCount < intArrCols - 2
            intRowCount = 0

            Do While intRowCount < intArrRows

                intCellCopy = arrayTempCols(intRowCount, intColCount)
                arrayMatrix(intRowCount, intColCount + 1) = intCellCopy

                intRowCount = intRowCount + 1
            Loop

            intColCount = intColCount + 1
        Loop

        ''Fill final column of the packed array
        'Fill final temporary array column with temporary matrix data
        intRowCount = 0
        intColCount = 0
        Do While intRowCount < intArrRows

            intCellCopy = arrayTempMatrix(intRowCount, intArrCols - 1)
            arrayMatrix(intRowCount, intArrCols - 1) = intCellCopy

            intRowCount = intRowCount + 1
        Loop
        intRowCount = 0
        intColCount = 0

        Do While intRowCount < intArrRows

            arraySpecies(intRowCount) = arraySpeciesKey(intRowCount)

            intRowCount = intRowCount + 1
        Loop

        Do While intColCount < intArrCols

            arraySites(intColCount) = arraySitesKey(intColCount)

            intColCount = intColCount + 1
        Loop

        'MessageBox.Show("End pack.")

        PackMatrix = arrayMatrix
        PackMatrix = arraySpecies
        PackMatrix = arraySites

    End Function

End Module
