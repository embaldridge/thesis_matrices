﻿
Public Class Batch
    Dim ofdOpenFileDialog2 As OpenFileDialog
    Dim ofdOpenFileDialog3 As OpenFileDialog
    Dim fbdInputFolder As FolderBrowserDialog
    Dim fbdOutputFolder As FolderBrowserDialog
    Dim strInputFolder As String
    Dim strOutputFolder As String
    Dim strKeyFile As String
    Dim strBatchOut As String
    Dim strInputFile As String
    Dim strOutputFile As String
    Dim boolInd As Boolean
    Dim boolOut As Boolean
    Dim boolNull As Boolean
    Dim intRandomizations As Integer
    Dim intNullNumber As Integer
    Dim intMetricNumber As Integer
    Dim arrayDataOut(6) As Double



    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        fbdInputFolder = New FolderBrowserDialog

        With fbdInputFolder
            .ShowNewFolderButton = True
            .RootFolder = Environment.SpecialFolder.MyComputer
            .SelectedPath = True

            If fbdInputFolder.ShowDialog = Windows.Forms.DialogResult.OK Then
                Try
                    strInputFolder = fbdInputFolder.SelectedPath
                Catch ex As Exception

                End Try
            End If
        End With
        Label9.Text = strInputFolder
    End Sub


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        fbdOutputFolder = New FolderBrowserDialog

        With fbdOutputFolder
            .ShowNewFolderButton = True
            .RootFolder = Environment.SpecialFolder.MyComputer
            .SelectedPath = True

            If fbdOutputFolder.ShowDialog = Windows.Forms.DialogResult.OK Then
                Try
                    strOutputFolder = fbdOutputFolder.SelectedPath
                Catch ex As Exception

                End Try
            End If
        End With
        Label10.Text = strOutputFolder
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        'Open File Dialog
        ofdOpenFileDialog2 = New OpenFileDialog
        'Locate input file
        With ofdOpenFileDialog2
            .AddExtension = True
            .AutoUpgradeEnabled = True
            .CheckFileExists = True
            .CheckPathExists = True
            .DefaultExt = ".xls,.xlsx"
            .Filter = "Excel files (*.xls)|*.xls|(*xlsx)|*.xlsx | Text files (*.txt)|*.txt"
            .Multiselect = False
            .ShowHelp = False
            .Title = "Select key file."
        End With
        If ofdOpenFileDialog2.ShowDialog = Windows.Forms.DialogResult.OK Then
            Try
                strKeyFile = ofdOpenFileDialog2.FileName
            Catch ex As Exception


            End Try
        End If

        Label1.Text = strKeyFile
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        'Open File Dialog
        ofdOpenFileDialog3 = New OpenFileDialog
        'Locate output file
        With ofdOpenFileDialog3
            .AddExtension = True
            .AutoUpgradeEnabled = True
            .CheckFileExists = True
            .CheckPathExists = True
            .DefaultExt = ".xls,.xlsx"
            .Filter = "Excel files (*.xls)|*.xls|(*xlsx)|*.xlsx | Text files (*.txt)|*.txt"
            .Multiselect = False
            .ShowHelp = False
            .Title = "Select output file."
        End With
        If ofdOpenFileDialog3.ShowDialog = Windows.Forms.DialogResult.OK Then
            Try
                strBatchOut = ofdOpenFileDialog3.FileName
            Catch ex As Exception

            End Try
        End If

        Label2.Text = strBatchOut
    End Sub

    Private Sub Batch_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        'Loading data into array
        Try

            'Make independant variable button boolean
            If RadioButton8.Checked = True Then
                boolInd = True
            Else
                boolInd = False
            End If

            'Make matrix output radio button boolean
            If RadioButton5.Checked = True Then
                boolOut = True
            Else
                boolOut = False
            End If

            'Put metric selection into a variable.
            If RadioButton9.Checked = True Then intMetricNumber = 1

            If RadioButton10.Checked = True Then intMetricNumber = 2

            If RadioButton11.Checked = True Then intMetricNumber = 3

            If RadioButton12.Checked = True Then intMetricNumber = 4

            If RadioButton13.Checked = True Then intMetricNumber = 5

            If RadioButton14.Checked = True Then intMetricNumber = 6

            If RadioButton15.Checked = True Then intMetricNumber = 7

            If RadioButton16.Checked = True Then intMetricNumber = 8

            If RadioButton17.Checked = True Then intMetricNumber = 9

            If RadioButton18.Checked = True Then intMetricNumber = 10

            If RadioButton19.Checked = True Then intMetricNumber = 11


            'Assign Randomizations Text Box value to variable
            Try
                intRandomizations = TextBox1.Text
            Catch ex As InvalidCastException

            End Try


            'Put null model selection into a variable.

            If RadioButton20.Checked = True Then intNullNumber = 1


            If RadioButton21.Checked = True Then intNullNumber = 2

            If RadioButton22.Checked = True Then intNullNumber = 3

            If RadioButton23.Checked = True Then intNullNumber = 4

            If RadioButton24.Checked = True Then intNullNumber = 5

            If RadioButton25.Checked = True Then intNullNumber = 6

            If RadioButton26.Checked = True Then intNullNumber = 7

            If RadioButton27.Checked = True Then intNullNumber = 8

            If RadioButton28.Checked = True Then intNullNumber = 9

            MessageBox.Show("Parameters loaded.")

            'Set up invisible Excel to handle input data
            Dim xlsObject3 As Microsoft.Office.Interop.Excel.Application
            xlsObject3 = New Microsoft.Office.Interop.Excel.Application

            Dim wbkInputFile3 As Microsoft.Office.Interop.Excel.Workbook
            Dim wksInputSheet3 As Microsoft.Office.Interop.Excel.Worksheet

            'Open input file
            xlsObject3.Application.Workbooks.Open(strKeyFile)
            wbkInputFile3 = GetObject(strKeyFile)
            wksInputSheet3 = wbkInputFile3.Worksheets(1) 'Data must be in the first worksheet

            'Get input data file parameters
            Dim intDataRows1 As Integer
            Dim intDataCols1 As Integer

            Dim rRows1 As Microsoft.Office.Interop.Excel.Range
            Dim rCols1 As Microsoft.Office.Interop.Excel.Range

            rRows1 = wksInputSheet3.Range("A:A")
            rCols1 = wksInputSheet3.Range("1:1")

            intDataRows1 = xlsObject3.WorksheetFunction.CountA(rRows1)
            intDataCols1 = xlsObject3.WorksheetFunction.CountA(rCols1)

            Dim intColCounter As Integer
            Dim intFileCounter As Integer
            Dim arrayFileLoad(intDataRows1, intDataCols1) As String
            Dim arrayBatchResults(intDataRows1, 6) As Double
            intFileCounter = 0


            Dim rCell3 As Microsoft.Office.Interop.Excel.Range
            'Load key file array
            intFileCounter = 0
            intColCounter = 0

            Do While intFileCounter < intDataRows1
                intColCounter = 0

                Do While intColCounter < intDataCols1

                    rCell3 = wksInputSheet3.Cells(intFileCounter + 1, intColCounter + 1)
                    arrayFileLoad(intFileCounter, intColCounter) = rCell3.Value

                    intColCounter = intColCounter + 1

                Loop

                intFileCounter = intFileCounter + 1

            Loop

            'Cleanup and close Excel application
            wbkInputFile3.Close()
            xlsObject3.Application.Quit()

            Dim intBatchCounter As Integer
            Dim intDataCounter As Integer

            intBatchCounter = 0
            intDataCounter = 0

            Do While intBatchCounter < intFileCounter
                intDataCounter = 0

                strInputFile = strInputFolder & "\" & arrayFileLoad(intBatchCounter, 0)
                strOutputFile = strOutputFolder & "\" & arrayFileLoad(intBatchCounter, 1)

                Call subloopInput(strInputFile, boolInd, boolOut, strOutputFile, boolNull, intNullNumber, intMetricNumber, intRandomizations, arrayDataOut)


                Do While intDataCounter < 6
                    arrayBatchResults(intBatchCounter, intDataCounter) = arrayDataOut(intDataCounter)

                    intDataCounter = intDataCounter + 1
                Loop

                intBatchCounter = intBatchCounter + 1

            Loop

            Dim xlsObject4 As Microsoft.Office.Interop.Excel.Application
            xlsObject4 = New Microsoft.Office.Interop.Excel.Application

            Dim wbkOutputFile As Microsoft.Office.Interop.Excel.Workbook
            Dim wksOutputSheet As Microsoft.Office.Interop.Excel.Worksheet

            Dim rCell4 As Microsoft.Office.Interop.Excel.Range

            'Open blank output file.
            xlsObject4.Application.Workbooks.Open(strBatchOut)
            wbkOutputFile = GetObject(strBatchOut)
            wksOutputSheet = wbkOutputFile.Worksheets(1) 'data is sent to the first worksheet.

            Dim intCounter As Integer
            Dim intCountOut As Integer

            intCounter = 0
            intCountOut = 0
            ''Label output
            wbkOutputFile = GetObject(strBatchOut)
            wksOutputSheet = wbkOutputFile.Worksheets(1) 'data is sent to the first worksheet.

            rCell4 = wksOutputSheet.Cells(1, 1)
            rCell4.Value = "File"

            rCell4 = wksOutputSheet.Cells(1, 2)
            rCell4.Value = "p-value"

            rCell4 = wksOutputSheet.Cells(1, 3)
            rCell4.Value = "Metric value"

            rCell4 = wksOutputSheet.Cells(1, 4)
            rCell4.Value = "Percent fill"

            rCell4 = wksOutputSheet.Cells(1, 5)
            rCell4.Value = "Matrix size"

            rCell4 = wksOutputSheet.Cells(1, 6)
            rCell4.Value = "Rows"

            rCell4 = wksOutputSheet.Cells(1, 7)
            rCell4.Value = "Columns"

            'Output file names
            Do While intCounter < intDataRows1


                rCell4 = wksOutputSheet.Cells(intCounter + 2, 1)
                rCell4.Value = arrayFileLoad(intCounter, 0)

                intCounter = intCounter + 1

            Loop

            'Output data values
            intCounter = 0
            intCountOut = 0

            Do While intCounter < intDataRows1
                intCountOut = 0

                Do While intCountOut < 6
                    rCell4 = wksOutputSheet.Cells(intCounter + 2, intCountOut + 2)
                    rCell4.Value = arrayBatchResults(intCounter, intCountOut)

                    intCountOut = intCountOut + 1
                Loop

                intCounter = intCounter + 1
            Loop

            'Save output file
            wbkOutputFile.Save()

            'Cleanup and close Excel application
            wbkOutputFile.Close()
            xlsObject3.Application.Quit()

            'MessageBox.Show("Run complete.")

            MessageBox.Show("Batch complete.")

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click

        Cudgel.Show()
        Me.Hide()



    End Sub
End Class



