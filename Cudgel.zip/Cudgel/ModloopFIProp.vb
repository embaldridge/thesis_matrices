﻿Module ModloopFIProp
    Public Function FIProp(ByRef arrayNull As Array, ByRef arrayMatrix As Array, ByRef intArrRows As Integer, ByRef intArrCols As Integer, ByRef intRandomCounter As Integer)

        Dim arrayRandom(intArrCols - 2) As Double
        Dim arrayTempRandom(intArrRows - 2, intArrCols - 2) As Double
        Dim intRowCounter As Integer
        Dim intColCounter As Integer
        Dim intCopyValue As Double
        Dim intPosRef As Integer
        Dim intValue As Double
        Dim intRandomCols As Integer
        Dim intRandomRows As Integer
        Dim intRandom As New Random

        ' ' Fixed- incidence proportional null model- Random 1 ' ' '

        '' Send observed matrix through without randomization
        If intRandomCounter = 0 Then

            FIProp = arrayMatrix

        Else

            'Shuffling protocol
            Dim intShuffle1 As Integer
            Dim intShuffle2 As Integer
            intRowCounter = 0
            intColCounter = 0
            intRandomCols = 0
            intRandomRows = 0

            Do While intRandomCols < intArrCols - 2

                arrayRandom(intRandomCols) = intRandomCols + 1

                intRandomCols = intRandomCols + 1
            Loop


            'Randomize and fill final array
            Do While intRowCounter < intArrRows - 2
                intRandomCols = 0
                intColCounter = 0

                Do While intRandomCols < intArrCols - 2

                    Randomize()

                    intPosRef = intRandom.Next(0, intArrCols - 3)
                    intValue = arrayRandom(intPosRef)
                    intCopyValue = arrayRandom(intRandomCols)


                    intShuffle1 = intValue
                    intShuffle2 = intCopyValue

                    arrayRandom(intRandomCols) = intShuffle1
                    arrayRandom(intPosRef) = intShuffle2

                    intRandomCols = intRandomCols + 1

                Loop

                'Fill final matrix using randomized key array
                Do While intColCounter < intArrCols - 2

                    intPosRef = arrayRandom(intColCounter)
                    intCopyValue = arrayNull(intRowCounter + 1, intPosRef)
                    arrayMatrix(intRowCounter + 1, intColCounter + 1) = intCopyValue

                    intColCounter = intColCounter + 1

                Loop

                intRowCounter = intRowCounter + 1
            Loop
            intRowCounter = 0
            intColCounter = 0

            FIProp = arrayMatrix
        End If
    End Function
End Module
