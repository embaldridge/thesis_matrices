﻿Module Tantalus
    Public Function subloopInput(ByVal strInputFile As String, ByRef boolInd As Boolean, ByRef boolOut As Boolean, ByVal strOutputFile As String, ByVal boolNull As Boolean, ByVal intNullNumber As Integer, ByVal intMetricNumber As Integer, ByRef intRandomizations As Integer, ByRef arrayDataOut As Array)
        'Set up invisible Excel to handle input data
        Dim douMetricVal As Double

        Dim xlsObject1 As Microsoft.Office.Interop.Excel.Application
        xlsObject1 = New Microsoft.Office.Interop.Excel.Application

        Dim wbkInputFile As Microsoft.Office.Interop.Excel.Workbook
        Dim wksInputSheet As Microsoft.Office.Interop.Excel.Worksheet

        'Open input file
        xlsObject1.Application.Workbooks.Open(strInputFile)
        wbkInputFile = GetObject(strInputFile)
        wksInputSheet = wbkInputFile.Worksheets(1) 'Data must be in the first worksheet

        'Get input data file parameters
        Dim intDataRows As Integer
        Dim intDataCols As Integer

        Dim rRows As Microsoft.Office.Interop.Excel.Range
        Dim rCols As Microsoft.Office.Interop.Excel.Range

        rRows = wksInputSheet.Range("A:A")
        rCols = wksInputSheet.Range("1:1")

        intDataRows = xlsObject1.WorksheetFunction.CountA(rRows)
        intDataCols = xlsObject1.WorksheetFunction.CountA(rCols)

        'Set up data array
        Dim intArrRows As Integer
        Dim intArrCols As Integer
        Dim intSpeciesRows As Integer
        Dim intSitesCols As Integer

        intArrRows = intDataRows
        intArrCols = intDataCols

        intSpeciesRows = intDataRows
        intSitesCols = intDataCols



        'Setup data array

        Dim arraySpecies(intSpeciesRows) As String

        Dim arraySites(intSitesCols) As String

        Dim arrayNull(intArrRows, intArrCols) As Double
        Dim arrayMatrix(intArrRows, intArrCols) As Double


        'Load data array
        Dim rCell As Microsoft.Office.Interop.Excel.Range

        Dim intRowLoop As Integer
        Dim intColLoop As Integer

        Dim intXlsRowPos As Integer
        Dim intXlsColPos As Integer


        'Load species name array

        intRowLoop = 0
        intColLoop = 0

        Do While intRowLoop < intDataRows

            rCell = wksInputSheet.Cells(intRowLoop + 1, 1)

            arraySpecies(intRowLoop) = rCell.Value

            intRowLoop = intRowLoop + 1

        Loop


        'Load sites array
        intRowLoop = 0
        intColLoop = 0

        Do While intColLoop < intDataCols

            rCell = wksInputSheet.Cells(1, intColLoop + 1)

            arraySites(intColLoop) = rCell.Value

            intColLoop = intColLoop + 1

        Loop

        'Load array matrix
        intRowLoop = 0
        intColLoop = 0


        Do While intRowLoop < intDataRows
            intColLoop = 0
            intXlsRowPos = intRowLoop + 2

            Do While intColLoop < intDataCols
                intXlsColPos = intColLoop + 2

                rCell = wksInputSheet.Cells(intXlsRowPos, intXlsColPos)

                arrayNull(intRowLoop, intColLoop) = rCell.Value
                arrayMatrix(intRowLoop, intColLoop) = rCell.Value

                intColLoop = intColLoop + 1

            Loop

            intRowLoop = intRowLoop + 1

        Loop


        'Cleanup and close Excel application
        wbkInputFile.Close()
        xlsObject1.Application.Quit()


        Dim intRandomCounter As Integer
        Dim arrayMatrixVals(intRandomizations) As Double

        intRandomCounter = 0

        Do While intRandomCounter < intRandomizations + 1


            'Call null model function

            If intNullNumber = 5 Then FIProp(arrayNull, arrayMatrix, intArrRows, intArrCols, intRandomCounter)


            'Call summarize function
            Call MatrixSummarize(arrayMatrix, boolInd, intArrRows, intArrCols, intRandomCounter)

            'Call packing function

            Call PackMatrix(arrayMatrix, arraySpecies, arraySites, intArrRows, intArrCols, intSpeciesRows, intSitesCols)

            If intRandomCounter = 0 And boolOut = True Then
                OutputMatrix(arrayMatrix, arraySpecies, arraySites, intArrRows, intArrCols, strOutputFile)
            End If



            'Call metric function
            If intMetricNumber = 1 Then No(arrayMatrix, intArrRows, intArrCols, douMetricVal)

            arrayMatrixVals(intRandomCounter) = douMetricVal


            intRandomCounter = intRandomCounter + 1

        Loop

        Call subpVal(arrayMatrixVals, intRandomizations, douMetricVal)

        Dim intSize As Integer

        intSize = ((intArrRows - 2) * (intArrCols - 2))

        Dim deciFill As Decimal

        Call subFill(intArrRows, intArrCols, arrayMatrix, intSize, deciFill)

        Call DataOutput(boolNull, arrayMatrixVals, strOutputFile, intRandomizations, douMetricVal, deciFill, intSize)

        'Fill batch output array
        arrayDataOut(0) = douMetricVal
        arrayDataOut(1) = arrayMatrixVals(0)
        arrayDataOut(2) = deciFill
        arrayDataOut(3) = intSize
        arrayDataOut(4) = intArrRows - 2
        arrayDataOut(5) = intArrCols - 2

        subloopInput = arrayDataOut(6)

    End Function
End Module
