﻿Module Fill
    Public Function subFill(ByVal intArrRows As Integer, ByVal intArrCols As Integer, ByRef arrayMatrix As Array, ByVal intSize As Integer, ByRef deciFill As Decimal)

        Dim intRowCount As Integer
        Dim intColCount As Integer
        Dim intCount As Integer
        Dim intPlace As Integer

        intRowCount = 0
        intColCount = 0
        intCount = 0

        Do While intRowCount < intArrRows - 2
            intColCount = 0

            Do While intColCount < intArrCols - 2

                intPlace = arrayMatrix(intRowCount + 1, intColCount + 1)

                If intPlace > 0.5 Then

                    intCount = intCount + 1

                Else

                    intCount = intCount + 0

                End If

                intColCount = intColCount + 1

            Loop

            intRowCount = intRowCount + 1

        Loop
    
        deciFill = (intCount / intSize)

        subFill = deciFill

    End Function

End Module
