﻿Module ModloopDataOutput
    Public Sub DataOutput(ByRef boolNull As Boolean, ByRef arrayMetricVals As Array, ByVal strOutputFile As String, ByVal intRandomizations As Integer, ByRef doupVal As Double, ByVal deciFill As Decimal, ByVal intSize As Integer)

        Dim xlsObject3 As Microsoft.Office.Interop.Excel.Application
        xlsObject3 = New Microsoft.Office.Interop.Excel.Application

        Dim wbkOutputFile As Microsoft.Office.Interop.Excel.Workbook
        Dim wksOutputSheet As Microsoft.Office.Interop.Excel.Worksheet

        Dim rCell3 As Microsoft.Office.Interop.Excel.Range

        Dim intCounter As Integer
        intCounter = 0


        'Open blank output file.
        xlsObject3.Application.Workbooks.Open(strOutputFile)
        wbkOutputFile = GetObject(strOutputFile)
        wksOutputSheet = wbkOutputFile.Worksheets(1) 'data is sent to the first worksheet.

        ''Output metric values

        'Output observed value
        rCell3 = wksOutputSheet.Cells(1)
        rCell3.Value = "Observed value"
        rCell3 = wksOutputSheet.Cells(2, 1)
        rCell3.Value = arrayMetricVals(intCounter)
        rCell3 = wksOutputSheet.Cells(4, 1)
        rCell3.Value = "Expected values"

        'Output p-value
        rCell3 = wksOutputSheet.Cells(1, 3)
        rCell3.Value = "p-Value"
        rCell3 = wksOutputSheet.Cells(2, 3)
        rCell3.Value = doupVal
        'MessageBox.Show(douObsVal.ToString & " = Observed value.")

        'Output percent fill
        rCell3 = wksOutputSheet.Cells(4, 3)
        rCell3.Value = "Percent fill"
        rCell3 = wksOutputSheet.Cells(5, 3)
        rCell3.Value = deciFill

        'Output matrix size
        rCell3 = wksOutputSheet.Cells(7, 3)
        rCell3.Value = "Matrix size"
        rCell3 = wksOutputSheet.Cells(8, 3)
        rCell3.Value = intSize


        Do While intCounter < intRandomizations

            wbkOutputFile = GetObject(strOutputFile)
            wksOutputSheet = wbkOutputFile.Worksheets(1) 'data is sent to the first worksheet.

            rCell3 = wksOutputSheet.Cells(intCounter + 5, 1)
            rCell3.Value = arrayMetricVals(intCounter + 1)
            'MessageBox.Show(rCell3.Value & " = Expected values.")

            intCounter = intCounter + 1

        Loop


        'Save output file
        wbkOutputFile.Save()

        'Cleanup and close Excel application
        wbkOutputFile.Close()
        xlsObject3.Application.Quit()

        'MessageBox.Show("Run complete.")


    End Sub

End Module
